package test;
import java.util.*;
import java.io.*;
public class Test {
    public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
        FileInputStream fis = new FileInputStream("DATA.in");
        BufferedInputStream bis = new BufferedInputStream(fis);
        ObjectInputStream ois = new ObjectInputStream(bis);
        ArrayList<Pair> a=(ArrayList<Pair>) ois.readObject();
        Collections.sort(a);
        Set<String> set=new HashSet<>();
        for(Pair i:a){
            if(!set.contains(i.toString())){
                set.add(i.toString());
                if(i.getFirst()<i.getSecond()){
                    System.out.println(i);
                }
            }           
        }
        ois.close();
        bis.close();
        fis.close();
    }   
    
}