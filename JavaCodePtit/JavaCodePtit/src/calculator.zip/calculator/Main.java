package calculator;

public class Main {
    public static void main(String[] args) {
        Calculator c = new Calculator();
    }
}